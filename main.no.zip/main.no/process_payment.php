<?php
require_once __DIR__ . '/src/helpers.php';
checkAuth();

$user = currentUser();
$pdo = getPDO();

$card_number = $_POST['card_number']; // Plain text card number
$card_holder = $_POST['card_holder'];
$expiry_date = $_POST['expiry_date']; // Plain text expiry date
$cvv = $_POST['cvv']; // Plain text CVV
$amount = $_POST['amount'];

if (!$card_number || !$card_holder || !$expiry_date || !$cvv || !$amount) {
    echo 'Все поля обязательны для заполнения.';
    exit;
}

try {
    $stmt = $pdo->prepare("INSERT INTO payments (user_id, card_number, card_holder, expiry_date, cvv, amount) VALUES (:user_id, :card_number, :card_holder, :expiry_date, :cvv, :amount)");
    $stmt->execute([
        'user_id' => $user['id'],
        'card_number' => $card_number,
        'card_holder' => $card_holder,
        'expiry_date' => $expiry_date,
        'cvv' => $cvv,
        'amount' => $amount,
    ]);
    echo 'success';
} catch (PDOException $e) {
    echo 'Ошибка при выполнении запроса: ' . $e->getMessage();
}
?>
