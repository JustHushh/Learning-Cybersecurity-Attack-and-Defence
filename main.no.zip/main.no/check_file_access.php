<?php

$url = 'http://main.no/config.php';
$response = file_get_contents($url);

if ($response === FALSE) {
    echo "Файл недоступен или доступ запрещен.";
} else {
    echo "Файл доступен!";
}
