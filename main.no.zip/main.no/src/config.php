<?php

const DB_HOST = 'localhost';
const DB_PORT = '3306';
const DB_NAME = 'areaweb';
const DB_USERNAME = 'root';
const DB_PASSWORD = '';