<?php
require_once __DIR__ . '/../helpers.php';
checkAuth();

$user = currentUser();
$new_password = $_POST['new_password'] ?? '';

// Логирование для отладки
$log_file = __DIR__ . '/debug.log';
file_put_contents($log_file, "Received request: " . print_r($_POST, true) . "\n", FILE_APPEND);

if (empty($new_password)) {
    file_put_contents($log_file, "Password is empty\n", FILE_APPEND);
    setMessage('error', 'Пароль не может быть пустым.');
    redirect('/home.php');
}

// Сохранение нового пароля (уязвимый вариант, без хэширования)
$pdo = getPDO();
$stmt = $pdo->prepare("UPDATE users SET password = :password WHERE id = :id");
$success = $stmt->execute(['password' => $new_password, 'id' => $user['id']]);

file_put_contents($log_file, "SQL executed: " . ($success ? 'success' : 'fail') . "\n", FILE_APPEND);

if ($success) {
    setMessage('success', 'Пароль успешно изменен.');
    file_put_contents($log_file, "Message set: Пароль успешно изменен\n", FILE_APPEND);
} else {
    setMessage('error', 'Ошибка изменения пароля.');
    file_put_contents($log_file, "Message set: Ошибка изменения пароля\n", FILE_APPEND);
}
redirect('/home.php');
?>
