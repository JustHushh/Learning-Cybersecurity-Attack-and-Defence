<?php
 require_once 'config.php'; // Подключи конфигурацию базы данных

 session_start();

 // Проверка, что форма была отправлена
 if ($_SERVER['REQUEST_METHOD'] === 'POST') {
     $surname = $_POST['surname'];
     $birthdate = $_POST['birthdate'];
     $region = $_POST['region'];
     $address = $_POST['address'];
     $userId = $_SESSION['user_id']; // Идентификатор пользователя из сессии

     // Валидация данных (простой пример)
     if (empty($surname) || empty($birthdate) || empty($region) || empty($address)) {
         echo "Пожалуйста, заполните все поля.";
     } else {
         // SQL-запрос на обновление данных пользователя
         $query = "UPDATE users SET surname = ?, birthdate = ?, region = ?, address = ? WHERE id = ?";
         $stmt = $conn->prepare($query);
         $stmt->bind_param("ssssi", $surname, $birthdate, $region, $address, $userId);
         $stmt->execute();

         if ($stmt->affected_rows > 0) {
             echo "Данные успешно обновлены.";
         } else {
             echo "Не удалось обновить данные.";
         }
         $stmt->close();
     }
     $conn->close();
 }
?>