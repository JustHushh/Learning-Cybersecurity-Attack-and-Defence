<?php
require_once __DIR__ . '/../helpers.php';
checkAuth();

$surname = $_POST['surname'] ?? null;
$birth_date = $_POST['birth_date'] ?? null;
$address = $_POST['address'] ?? null;

$user = currentUser();
$pdo = getPDO();

// Check if profile already exists
$stmt = $pdo->prepare("SELECT * FROM user_profiles WHERE user_id = :user_id");
$stmt->execute(['user_id' => $user['id']]);
$profile = $stmt->fetch(PDO::FETCH_ASSOC);

if ($profile) {
    // Update existing profile
    $stmt = $pdo->prepare("UPDATE user_profiles SET surname = :surname, birth_date = :birth_date, address = :address WHERE user_id = :user_id");
    $stmt->execute([
        'surname' => $surname,
        'birth_date' => $birth_date,
        'address' => $address,
        'user_id' => $user['id']
    ]);
} else {
    // Insert new profile
    $stmt = $pdo->prepare("INSERT INTO user_profiles (user_id, surname, birth_date, address) VALUES (:user_id, :surname, :birth_date, :address)");
    $stmt->execute([
        'user_id' => $user['id'],
        'surname' => $surname,
        'birth_date' => $birth_date,
        'address' => $address
    ]);
}

setMessage('success', 'Профиль обновлен');
redirect('/home.php');
