<?php

require_once __DIR__ . '/../helpers.php';
require_once __DIR__ . '/../config.php'; // Подключаем конфигурационный файл

$email = $_POST['email'] ?? null;
$password = $_POST['password'] ?? null;

if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    setOldValue('email', $email);
    setValidationError('email', 'Неверный формат электронной почты');
    setMessage('error', 'Ошибка валидации');
    redirect('/index.php');
}

// Подключение к базе данных
$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME, DB_PORT);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Параметры для тайм-аута и количества попыток
$timeout_duration = 5 * 60; // 5 минут в секундах
$max_attempts = 5; // Максимальное количество попыток

// Получение информации о попытках входа
$sql = "SELECT attempts, last_attempt FROM login_attempts WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$attempt = $result->fetch_assoc();

$now = new DateTime();
$current_time = $now->getTimestamp();

if ($attempt) {
    $last_attempt = new DateTime($attempt['last_attempt']);
    $last_attempt_time = $last_attempt->getTimestamp();
    $time_diff = $current_time - $last_attempt_time;

    if ($attempt['attempts'] >= $max_attempts && $time_diff < $timeout_duration) {
        setMessage('error', 'Слишком много неудачных попыток. Пожалуйста, попробуйте через 5 минут.');
        $stmt->close();
        $conn->close();
        redirect('/index.php');
    } elseif ($time_diff >= $timeout_duration) {
        // Сбросить счетчик попыток после истечения тайм-аута
        $sql = "UPDATE login_attempts SET attempts = 0 WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->close();
    }
} else {
    // Инициализация записи о попытках входа, если её не существует
    $sql = "INSERT INTO login_attempts (email) VALUES (?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->close();
}

// Проверка учетных данных пользователя
$user = findUser($email);
if (!$user) {
    $sql = "UPDATE login_attempts SET attempts = attempts + 1, last_attempt = NOW() WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->close();

    setMessage('error', "Пользователь $email не найден");
    $conn->close();
    redirect('/index.php');
}

if (!password_verify($password, $user['password'])) {
    $sql = "UPDATE login_attempts SET attempts = attempts + 1, last_attempt = NOW() WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->close();

    setMessage('error', 'Неверный пароль');
    $conn->close();
    redirect('/index.php');
}

// Сбросить счетчик попыток при успешном входе
$sql = "UPDATE login_attempts SET attempts = 0, last_attempt = NOW() WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->close();

$_SESSION['user']['id'] = $user['id'];

$conn->close();
redirect('/home.php');
