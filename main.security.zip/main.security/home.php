<?php
require_once __DIR__ . '/src/helpers.php';
checkAuth();
$user = currentUser();

// Fetch user profile
$pdo = getPDO();
$stmt = $pdo->prepare("SELECT * FROM user_profiles WHERE user_id = :user_id");
$stmt->execute(['user_id' => $user['id']]);
$profile = $stmt->fetch(PDO::FETCH_ASSOC);

// Функция для безопасного отображения данных
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="ru" data-theme="light">
<head>
    <title>Личный кабинет</title>
    <link rel="stylesheet" href="/assets/app.css">
    <style>
        .profile-info { margin-bottom: 20px; }
        .profile-info p { margin: 5px 0; }
        .form-group { margin-bottom: 15px; }
        .error { color: red; display: none; }
        .form-control.error { border-color: red; }
        .message { color: green; }
        .message.error { color: red; }
    </style>
</head>
<body>
    <?php include_once __DIR__ . '/components/head.php'; ?>
    <div class="card">
        <h2>Личный кабинет</h2>
        <img
        class="avatar"
        src="<?php echo e($user['avatar']) ?>"
        alt="<?php echo e($user['name']) ?>"
    >
        <p>Привет, <?php echo e($user['name']); ?></p>

        <?php if (hasMessage('success')): ?>
            <p class="message"><?php echo e(getMessage('success')); ?></p>
        <?php elseif (hasMessage('error')): ?>
            <p class="message error"><?php echo e(getMessage('error')); ?></p>
        <?php endif; ?>

        <div class="profile-info" id="profileInfo">
            <p><strong>Фамилия:</strong> <?php echo e($profile['surname'] ?? 'Не указано'); ?></p>
            <p><strong>Дата рождения:</strong> <?php echo e($profile['birth_date'] ?? 'Не указано'); ?></p>
            <p><strong>Адрес:</strong> <?php echo e($profile['address'] ?? 'Не указано'); ?></p>
        </div>

        <button class="btn" id="editProfileButton">Редактировать профиль</button>

        <form action="src/actions/logout.php" method="post">
            <button role="button">Выйти из аккаунта</button>
            <a href='index.html'>Назад</a>
        </form>

        <form id="profileForm" action="src/actions/update_profile.php" method="post" style="display:none;">
            <div class="form-group">
                <label for="surname">Фамилия:</label>
                <input type="text" id="surname" name="surname" class="form-control" value="<?php echo e($profile['surname'] ?? ''); ?>">
                <div class="error" id="surnameError">Заполните поле</div>
            </div>
            <div class="form-group">
                <label for="birth_date">Дата рождения:</label>
                <input type="date" id="birth_date" name="birth_date" class="form-control" value="<?php echo e($profile['birth_date'] ?? ''); ?>">
                <div class="error" id="birthDateError">Заполните поле</div>
            </div>
            <div class="form-group">
                <label for="address">Адрес:</label>
                <textarea id="address" name="address" class="form-control"><?php echo e($profile['address'] ?? ''); ?></textarea>
                <div class="error" id="addressError">Заполните поле</div>
            </div>
            <button type="submit" class="btn btn-primary" id="saveProfileButton" disabled>Сохранить</button>
        </form>

        <button class="btn" id="changePasswordButton" style="display:none;">Сменить пароль</button>

        <form id="changePasswordForm" action="src/actions/change_password.php" method="post" style="display:none;">
            <input type="hidden" name="csrf_token" value="<?php echo e(generateCsrfToken()); ?>">
            <div class="form-group">
                <label for="new_password">Новый пароль:</label>
                <input type="password" id="new_password" name="new_password" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary" id="savePasswordButton" disabled>Сохранить пароль</button>
        </form>
    </div>
    <?php include_once __DIR__ . '/components/scripts.php'; ?>
    <script src="/assets/js/main.js"></script>
    <script>
        document.getElementById('editProfileButton').addEventListener('click', function() {
            this.style.display = 'none';
            document.getElementById('profileInfo').style.display = 'none';
            document.getElementById('profileForm').style.display = 'block';
            document.getElementById('changePasswordButton').style.display = 'block';
        });

        document.getElementById('changePasswordButton').addEventListener('click', function() {
            this.style.display = 'none';
            document.getElementById('changePasswordForm').style.display = 'block';
        });

        const profileFields = ['surname', 'birth_date', 'address'];
        const saveProfileButton = document.getElementById('saveProfileButton');

        profileFields.forEach(field => {
            document.getElementById(field).addEventListener('input', function() {
                let allFilled = true;
                profileFields.forEach(f => {
                    if (!document.getElementById(f).value.trim()) {
                        allFilled = false;
                    }
                });
                saveProfileButton.disabled = !allFilled;
            });
        });

        const passwordField = document.getElementById('new_password');
        const savePasswordButton = document.getElementById('savePasswordButton');

        passwordField.addEventListener('input', function() {
            savePasswordButton.disabled = !passwordField.value.trim();
        });
    </script>
</body>
</html>
