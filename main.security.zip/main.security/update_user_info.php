<?php
require_once __DIR__ . '/../helpers.php';
checkAuth();
$user = currentUser();

$pdo = getPDO();

// Фильтрация входных данных
$surname = filter_input(INPUT_POST, 'surname', FILTER_SANITIZE_STRING);
$birth_date = filter_input(INPUT_POST, 'birth_date', FILTER_SANITIZE_STRING);
$address = filter_input(INPUT_POST, 'address', FILTER_SANITIZE_STRING);

// Проверка на пустые значения
if (empty($surname) || empty($birth_date) || empty($address)) {
    setMessage('error', 'Все поля должны быть заполнены.');
    redirect('/home.php');
}

// Обновление профиля пользователя в базе данных
$stmt = $pdo->prepare("UPDATE user_profiles SET surname = :surname, birth_date = :birth_date, address = :address WHERE user_id = :user_id");
$result = $stmt->execute([
    'surname' => $surname,
    'birth_date' => $birth_date,
    'address' => $address,
    'user_id' => $user['id']
]);

if ($result) {
    setMessage('success', 'Профиль успешно обновлен.');
} else {
    setMessage('error', 'Ошибка обновления профиля.');
}

redirect('/home.php');
?>
